import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-routing2',
  templateUrl: './routing2.component.html',
  styleUrls: ['./routing2.component.css']
})
export class Routing2Component implements OnInit {

  Routing2Title="I am component routing 2";
  constructor() { }

  ngOnInit(): void {
  }

}
